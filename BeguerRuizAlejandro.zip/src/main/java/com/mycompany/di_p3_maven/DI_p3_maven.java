/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.di_p3_maven;

/**
 *
 * @author USER
 */
public class DI_p3_maven {

     public static void main(String[] args) {
        
        Menu m = new Menu();
        m.setVisible(true);
        
        System.out.println("Aplicacion funcionando correctamente");
    }
    
}